# Golf Trip 2026 Dashboard

A beautiful comparison dashboard for golf trip options in Spain, September 2026.

## Features

- 3 side-by-side trip comparisons
- Detailed golf schedules
- Comprehensive comparison table
- Payment schedule breakdown
- Value analysis for each option
- Fully responsive design

## Deploy to Vercel

### Option 1: Deploy via Vercel Dashboard (Easiest)

1. Go to [vercel.com](https://vercel.com) and sign in with GitHub
2. Click "Add New..." → "Project"
3. Import your Git repository
4. Vercel will automatically detect Next.js
5. Click "Deploy"
6. Done! Your site will be live in ~2 minutes

### Option 2: Deploy via Vercel CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Navigate to project directory
cd golf-trip-dashboard

# Deploy
vercel
```

## Local Development

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Open http://localhost:3000 in your browser
```

## Project Structure

```
golf-trip-dashboard/
├── app/
│   └── page.tsx          # Main dashboard page
├── package.json          # Dependencies
├── tsconfig.json         # TypeScript config
├── next.config.js        # Next.js config
└── README.md            # This file
```

## Technologies

- Next.js 14
- TypeScript
- React 18
- CSS-in-JS

## Customization

To update trip details, edit the content in `app/page.tsx`.

The styling is embedded in the same file for easy customization.

---

Created with ❤️ for your golf trip planning
