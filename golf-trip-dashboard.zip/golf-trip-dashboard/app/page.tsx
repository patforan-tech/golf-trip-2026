export default function Home() {
  return (
    <html lang="en">
      <head>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Golf Trip 2026 - Comparison Dashboard</title>
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet" />
        <style>{`
          :root {
            --primary-green: #1a5f3a;
            --accent-gold: #d4af37;
            --light-bg: #f8f9f5;
            --card-bg: #ffffff;
            --text-dark: #1a1a1a;
            --text-muted: #666666;
            --border-color: #e0e5dc;
            --success: #2d6a4f;
            --warning: #d97706;
          }

          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }

          body {
            font-family: 'DM Sans', sans-serif;
            background: linear-gradient(135deg, #f8f9f5 0%, #e8ede2 100%);
            color: var(--text-dark);
            line-height: 1.6;
            min-height: 100vh;
            padding: 2rem 1rem;
          }

          .container {
            max-width: 1400px;
            margin: 0 auto;
            animation: fadeIn 0.8s ease-out;
          }

          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
          }

          header {
            text-align: center;
            margin-bottom: 3rem;
            animation: slideDown 0.6s ease-out;
          }

          @keyframes slideDown {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
          }

          h1 {
            font-family: 'Playfair Display', serif;
            font-size: 3.5rem;
            font-weight: 900;
            color: var(--primary-green);
            margin-bottom: 0.5rem;
            letter-spacing: -1px;
          }

          .subtitle {
            font-size: 1.1rem;
            color: var(--text-muted);
            font-weight: 500;
          }

          .comparison-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1.5rem;
            margin-bottom: 3rem;
          }

          .trip-card {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2.5rem;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
            border: 2px solid var(--border-color);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            animation: cardSlideIn 0.6s ease-out backwards;
          }

          .trip-card:nth-child(1) { animation-delay: 0.1s; }
          .trip-card:nth-child(2) { animation-delay: 0.2s; }
          .trip-card:nth-child(3) { animation-delay: 0.3s; }

          @keyframes cardSlideIn {
            from { opacity: 0; transform: translateX(-30px); }
            to { opacity: 1; transform: translateX(0); }
          }

          .trip-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 50px rgba(26, 95, 58, 0.15);
          }

          .card-header {
            border-bottom: 3px solid var(--accent-gold);
            padding-bottom: 1.5rem;
            margin-bottom: 2rem;
          }

          .card-title {
            font-family: 'Playfair Display', serif;
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-green);
            margin-bottom: 0.5rem;
          }

          .card-location {
            font-size: 1.1rem;
            color: var(--text-muted);
            font-weight: 500;
          }

          .price-badge {
            display: inline-block;
            background: linear-gradient(135deg, var(--primary-green), var(--success));
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 50px;
            font-size: 1.8rem;
            font-weight: 700;
            margin-top: 1rem;
            box-shadow: 0 4px 15px rgba(26, 95, 58, 0.3);
          }

          .info-table {
            width: 100%;
            margin: 1.5rem 0;
          }

          .info-row {
            display: grid;
            grid-template-columns: 180px 1fr;
            gap: 1rem;
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
            align-items: center;
          }

          .info-row:last-child {
            border-bottom: none;
          }

          .info-label {
            font-weight: 700;
            color: var(--primary-green);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }

          .info-value {
            font-size: 1rem;
            color: var(--text-dark);
          }

          .badge {
            display: inline-block;
            padding: 0.35rem 0.9rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            margin: 0.2rem;
          }

          .badge-yes {
            background: #d1fae5;
            color: #065f46;
          }

          .badge-no {
            background: #fee2e2;
            color: #991b1b;
          }

          .badge-partial {
            background: #fef3c7;
            color: #92400e;
          }

          .golf-rounds-section {
            background: var(--light-bg);
            border-radius: 12px;
            padding: 1.5rem;
            margin-top: 1.5rem;
          }

          .golf-rounds-section h3 {
            font-family: 'Playfair Display', serif;
            color: var(--primary-green);
            font-size: 1.3rem;
            margin-bottom: 1rem;
          }

          .round-item {
            background: white;
            padding: 1rem;
            margin-bottom: 0.8rem;
            border-radius: 8px;
            border-left: 4px solid var(--accent-gold);
          }

          .round-date {
            font-weight: 700;
            color: var(--primary-green);
            font-size: 0.9rem;
            margin-bottom: 0.3rem;
          }

          .round-course {
            font-size: 1rem;
            color: var(--text-dark);
            margin-bottom: 0.3rem;
          }

          .round-details {
            font-size: 0.85rem;
            color: var(--text-muted);
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
          }

          .summary-section {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2.5rem;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
            border: 2px solid var(--border-color);
            margin-top: 3rem;
            animation: cardSlideIn 0.6s ease-out 0.3s backwards;
          }

          .summary-title {
            font-family: 'Playfair Display', serif;
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-green);
            margin-bottom: 2rem;
            text-align: center;
          }

          .comparison-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            overflow: hidden;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
          }

          .comparison-table thead {
            background: linear-gradient(135deg, var(--primary-green), var(--success));
            color: white;
          }

          .comparison-table th {
            padding: 1.2rem;
            text-align: left;
            font-weight: 700;
            font-size: 0.95rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }

          .comparison-table tbody tr {
            background: white;
            transition: background 0.2s ease;
          }

          .comparison-table tbody tr:nth-child(even) {
            background: var(--light-bg);
          }

          .comparison-table tbody tr:hover {
            background: #e8f5e9;
          }

          .comparison-table td {
            padding: 1.2rem;
            border-bottom: 1px solid var(--border-color);
            font-size: 0.95rem;
          }

          .comparison-table tbody tr:last-child td {
            border-bottom: none;
          }

          .winner-badge {
            background: var(--accent-gold);
            color: var(--text-dark);
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-weight: 700;
            font-size: 0.85rem;
            display: inline-block;
          }

          .deposit-section {
            background: var(--light-bg);
            border-radius: 12px;
            padding: 2rem;
            margin-top: 2rem;
          }

          .deposit-section h3 {
            font-family: 'Playfair Display', serif;
            color: var(--primary-green);
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            text-align: center;
          }

          .deposit-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1.5rem;
          }

          .deposit-card {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
            border-top: 4px solid var(--accent-gold);
          }

          .deposit-label {
            font-size: 0.9rem;
            color: var(--text-muted);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.5rem;
          }

          .deposit-amount {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-green);
            margin-bottom: 0.5rem;
          }

          .deposit-date {
            font-size: 0.9rem;
            color: var(--text-muted);
          }

          .bonus-box {
            background: #fef3c7;
            padding: 1rem;
            border-radius: 8px;
            margin-top: 1rem;
            border-left: 4px solid var(--accent-gold);
          }

          .value-analysis {
            background: var(--light-bg);
            padding: 2rem;
            border-radius: 12px;
            margin-top: 2rem;
            border-left: 6px solid var(--accent-gold);
          }

          .value-analysis h3 {
            font-family: 'Playfair Display', serif;
            color: var(--primary-green);
            margin-bottom: 1rem;
          }

          .value-analysis h4 {
            color: var(--primary-green);
            margin-bottom: 0.5rem;
          }

          .value-option {
            margin-bottom: 1.5rem;
          }

          .value-option p {
            font-size: 1rem;
            line-height: 1.8;
          }

          @media (max-width: 1024px) {
            .comparison-grid {
              grid-template-columns: 1fr;
            }
            
            .deposit-grid {
              grid-template-columns: 1fr;
            }

            h1 {
              font-size: 2.5rem;
            }
          }
        `}</style>
      </head>
      <body>
        <div className="container">
          <header>
            <h1>⛳ Golf Trip 2026</h1>
            <p className="subtitle">Spain • September 24-29, 2026 • 5 Nights • 10 Golfers</p>
          </header>

          <div className="comparison-grid">
            {/* Card 1: H10 Salou Princess */}
            <div className="trip-card">
              <div className="card-header">
                <h2 className="card-title">H10 Salou Princess</h2>
                <p className="card-location">📍 Salou, Spain</p>
                <div className="price-badge">£605 pp</div>
              </div>

              <div className="info-table">
                <div className="info-row">
                  <div className="info-label">Date</div>
                  <div className="info-value">24-29 September 2026</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Hotel</div>
                  <div className="info-value">H10 Salou Princess</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Room Type</div>
                  <div className="info-value">Standard Room</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Board Basis</div>
                  <div className="info-value">Half Board</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Rounds of Golf</div>
                  <div className="info-value">3 Rounds</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Golf Courses</div>
                  <div className="info-value">
                    Infinitum Hills Course (×2)<br />
                    Infinitum Lakes Course (×1)
                  </div>
                </div>
                <div className="info-row">
                  <div className="info-label">Transfers</div>
                  <div className="info-value">
                    <span className="badge badge-partial">Partial</span>
                    <br /><small>Golf: Only Lakes Course<br />Airport: Not included</small>
                  </div>
                </div>
                <div className="info-row">
                  <div className="info-label">Buggies</div>
                  <div className="info-value">
                    <span className="badge badge-partial">Partial</span>
                    <br /><small>1-2 rounds included</small>
                  </div>
                </div>
                <div className="info-row">
                  <div className="info-label">Total Price</div>
                  <div className="info-value" style={{fontSize: '1.3rem', fontWeight: 700, color: 'var(--primary-green)'}}>£6,050.00</div>
                </div>
              </div>

              <div className="golf-rounds-section">
                <h3>⛳ Golf Schedule</h3>
                <div className="round-item">
                  <div className="round-date">Friday, 25 September</div>
                  <div className="round-course">Infinitum Hills Course</div>
                  <div className="round-details">
                    <span>🚗 No transfers</span>
                    <span>🏌️ No buggy</span>
                  </div>
                </div>
                <div className="round-item">
                  <div className="round-date">Saturday, 26 September</div>
                  <div className="round-course">Infinitum Lakes Course</div>
                  <div className="round-details">
                    <span>✅ Transfers included</span>
                    <span>✅ Shared buggy</span>
                  </div>
                </div>
                <div className="round-item">
                  <div className="round-date">Monday, 28 September</div>
                  <div className="round-course">Infinitum Hills Course</div>
                  <div className="round-details">
                    <span>🚗 No transfers</span>
                    <span>🏌️ No buggy</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Card 2: Sandos Griego Hotel */}
            <div className="trip-card">
              <div className="card-header">
                <h2 className="card-title">Sandos Griego Hotel</h2>
                <p className="card-location">📍 Málaga, Costa del Sol</p>
                <div className="price-badge">£825 pp</div>
              </div>

              <div className="info-table">
                <div className="info-row">
                  <div className="info-label">Date</div>
                  <div className="info-value">24-29 September 2026</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Hotel</div>
                  <div className="info-value">Sandos Griego Hotel</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Room Type</div>
                  <div className="info-value">Standard Room</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Board Basis</div>
                  <div className="info-value">All Inclusive ⭐</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Rounds of Golf</div>
                  <div className="info-value">3 Rounds</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Golf Courses</div>
                  <div className="info-value">
                    El Chaparral Golf Club<br />
                    Golf Torrequebrada<br />
                    Santana Golf Club
                  </div>
                </div>
                <div className="info-row">
                  <div className="info-label">Transfers</div>
                  <div className="info-value">
                    <span className="badge badge-yes">Yes</span>
                    <br /><small>Golf: All 3 rounds<br />Airport: Included ✈️</small>
                  </div>
                </div>
                <div className="info-row">
                  <div className="info-label">Buggies</div>
                  <div className="info-value">
                    <span className="badge badge-yes">Yes</span>
                    <br /><small>All 3 rounds (5 buggies)</small>
                  </div>
                </div>
                <div className="info-row">
                  <div className="info-label">Total Price</div>
                  <div className="info-value" style={{fontSize: '1.3rem', fontWeight: 700, color: 'var(--primary-green)'}}>£8,250.00</div>
                </div>
              </div>

              <div className="golf-rounds-section">
                <h3>⛳ Golf Schedule</h3>
                <div className="round-item">
                  <div className="round-date">Friday, 25 September</div>
                  <div className="round-course">El Chaparral Golf Club</div>
                  <div className="round-details">
                    <span>✅ Transfers included</span>
                    <span>✅ Shared buggy</span>
                  </div>
                </div>
                <div className="round-item">
                  <div className="round-date">Saturday, 26 September</div>
                  <div className="round-course">Golf Torrequebrada</div>
                  <div className="round-details">
                    <span>✅ Transfers included</span>
                    <span>✅ 5 buggies</span>
                  </div>
                </div>
                <div className="round-item">
                  <div className="round-date">Monday, 28 September</div>
                  <div className="round-course">Santana Golf Club</div>
                  <div className="round-details">
                    <span>✅ Transfers included</span>
                    <span>✅ 5 buggies</span>
                  </div>
                </div>
              </div>

              <div className="bonus-box">
                <strong>🎁 Bonus:</strong> €20 drinks credit per person at &quot;The Clubhouse Marbella&quot;
              </div>
            </div>

            {/* Card 3: BlueBay Banus */}
            <div className="trip-card">
              <div className="card-header">
                <h2 className="card-title">BlueBay Banus</h2>
                <p className="card-location">📍 Marbella, Málaga</p>
                <div className="price-badge">£625 pp</div>
              </div>

              <div className="info-table">
                <div className="info-row">
                  <div className="info-label">Date</div>
                  <div className="info-value">24-29 September 2026</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Hotel</div>
                  <div className="info-value">BlueBay Banus</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Room Type</div>
                  <div className="info-value">Standard Room</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Board Basis</div>
                  <div className="info-value">Bed and Breakfast</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Rounds of Golf</div>
                  <div className="info-value">3 Rounds</div>
                </div>
                <div className="info-row">
                  <div className="info-label">Golf Courses</div>
                  <div className="info-value">
                    La Quinta Golf Club<br />
                    Marbella Golf Country Club<br />
                    Flamingos Golf Club
                  </div>
                </div>
                <div className="info-row">
                  <div className="info-label">Transfers</div>
                  <div className="info-value">
                    <span className="badge badge-yes">Yes</span>
                    <br /><small>Golf: All 3 rounds<br />Airport: Included ✈️</small>
                  </div>
                </div>
                <div className="info-row">
                  <div className="info-label">Buggies</div>
                  <div className="info-value">
                    <span className="badge badge-partial">Partial</span>
                    <br /><small>1 round (Marbella CC)</small>
                  </div>
                </div>
                <div className="info-row">
                  <div className="info-label">Total Price</div>
                  <div className="info-value" style={{fontSize: '1.3rem', fontWeight: 700, color: 'var(--primary-green)'}}>£6,250.00</div>
                </div>
              </div>

              <div className="golf-rounds-section">
                <h3>⛳ Golf Schedule</h3>
                <div className="round-item">
                  <div className="round-date">Friday, 25 September</div>
                  <div className="round-course">La Quinta Golf Club</div>
                  <div className="round-details">
                    <span>✅ Transfers included</span>
                    <span>🏌️ No buggy</span>
                  </div>
                </div>
                <div className="round-item">
                  <div className="round-date">Saturday, 26 September</div>
                  <div className="round-course">Marbella Golf Country Club</div>
                  <div className="round-details">
                    <span>✅ Transfers included</span>
                    <span>✅ Shared buggy</span>
                  </div>
                </div>
                <div className="round-item">
                  <div className="round-date">Monday, 28 September</div>
                  <div className="round-course">Flamingos Golf Club</div>
                  <div className="round-details">
                    <span>✅ Transfers included</span>
                    <span>🏌️ No buggy</span>
                  </div>
                </div>
              </div>

              <div className="bonus-box">
                <strong>🎁 Bonus:</strong> €20 drinks credit per person at &quot;The Clubhouse Marbella&quot;
              </div>
            </div>
          </div>

          {/* Summary Comparison Section */}
          <div className="summary-section">
            <h2 className="summary-title">📊 Quick Comparison</h2>
            
            <table className="comparison-table">
              <thead>
                <tr>
                  <th>Factor</th>
                  <th>H10 Salou Princess</th>
                  <th>Sandos Griego Hotel</th>
                  <th>BlueBay Banus</th>
                  <th>Winner</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><strong>Price</strong></td>
                  <td>£605 pp</td>
                  <td>£825 pp</td>
                  <td>£625 pp</td>
                  <td><span className="winner-badge">H10 Salou (Cheapest)</span></td>
                </tr>
                <tr>
                  <td><strong>Food & Drink</strong></td>
                  <td>Half Board</td>
                  <td>All Inclusive</td>
                  <td>Bed & Breakfast</td>
                  <td><span className="winner-badge">Sandos Griego</span></td>
                </tr>
                <tr>
                  <td><strong>Airport Transfers</strong></td>
                  <td>❌ Not included</td>
                  <td>✅ Included</td>
                  <td>✅ Included</td>
                  <td><span className="winner-badge">Sandos & BlueBay</span></td>
                </tr>
                <tr>
                  <td><strong>Golf Transfers</strong></td>
                  <td>Partial (1 round)</td>
                  <td>All 3 rounds</td>
                  <td>All 3 rounds</td>
                  <td><span className="winner-badge">Sandos & BlueBay</span></td>
                </tr>
                <tr>
                  <td><strong>Buggies</strong></td>
                  <td>1-2 rounds</td>
                  <td>All 3 rounds</td>
                  <td>1 round</td>
                  <td><span className="winner-badge">Sandos Griego</span></td>
                </tr>
                <tr>
                  <td><strong>Golf Variety</strong></td>
                  <td>Same resort (Infinitum)</td>
                  <td>3 different courses</td>
                  <td>3 different courses</td>
                  <td><span className="winner-badge">Sandos & BlueBay</span></td>
                </tr>
                <tr>
                  <td><strong>Location</strong></td>
                  <td>Salou</td>
                  <td>Costa del Sol (Málaga)</td>
                  <td>Marbella (Málaga)</td>
                  <td><span className="winner-badge">Personal preference</span></td>
                </tr>
              </tbody>
            </table>

            <div className="deposit-section">
              <h3>💰 Payment Schedule (All Options)</h3>
              <div className="deposit-grid">
                <div className="deposit-card">
                  <div className="deposit-label">Initial Deposit</div>
                  <div className="deposit-amount">£300</div>
                  <div className="deposit-date">Upon booking</div>
                </div>
                <div className="deposit-card">
                  <div className="deposit-label">Second Deposit</div>
                  <div className="deposit-amount">£450</div>
                  <div className="deposit-date">31 December 2025</div>
                </div>
                <div className="deposit-card">
                  <div className="deposit-label">Final Balance</div>
                  <div className="deposit-amount">Remaining</div>
                  <div className="deposit-date">2 July 2026</div>
                </div>
              </div>
            </div>

            <div className="value-analysis">
              <h3>💡 Value Analysis</h3>
              
              <div className="value-option">
                <h4>Option 1: H10 Salou Princess - £605 pp (£6,050 total)</h4>
                <p>
                  ✅ <strong>Cheapest option</strong><br />
                  ✅ Half Board (breakfast + dinner)<br />
                  ✅ 3 rounds at quality Infinitum courses<br />
                  ❌ Limited transfers (only 1 round)<br />
                  ❌ No airport transfers<br />
                  ❌ Limited buggies (1-2 rounds)<br />
                  <strong style={{color: 'var(--primary-green)'}}>Best for: Budget-conscious groups who don&apos;t mind arranging own transport</strong>
                </p>
              </div>

              <div className="value-option">
                <h4>Option 2: Sandos Griego Hotel - £825 pp (£8,250 total)</h4>
                <p>
                  ✅ <strong>All Inclusive</strong> (unlimited food & drinks)<br />
                  ✅ Airport transfers both ways<br />
                  ✅ All golf transfers included<br />
                  ✅ Buggies for all 3 rounds<br />
                  ✅ 3 different golf courses<br />
                  ✅ €20 drinks credit bonus<br />
                  ❌ Most expensive (+£220 per person vs H10 Salou)<br />
                  <strong style={{color: 'var(--primary-green)'}}>Best for: Groups wanting premium all-inclusive experience with no hassle</strong>
                </p>
              </div>

              <div className="value-option">
                <h4>Option 3: BlueBay Banus - £625 pp (£6,250 total)</h4>
                <p>
                  ✅ <strong>Great middle-ground price</strong> (only £20 more than H10 Salou)<br />
                  ✅ Airport transfers both ways<br />
                  ✅ All golf transfers included<br />
                  ✅ 3 different quality courses<br />
                  ✅ Marbella location (near Puerto Banús)<br />
                  ✅ €20 drinks credit bonus<br />
                  ❌ Bed & Breakfast only (no dinner)<br />
                  ❌ Limited buggies (1 round only)<br />
                  <strong style={{color: 'var(--primary-green)'}}>Best for: Groups wanting transfers included at good value, happy to eat out in Marbella</strong>
                </p>
              </div>
            </div>
          </div>
        </div>
      </body>
    </html>
  );
}
